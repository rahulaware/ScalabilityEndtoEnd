import os
import sys

if len(sys.argv)<4:
    print "Command Usage:"
    print "python create_serverFlow.py startIP NumberOfDevices typeOfDevice(window,linux)"
    exit();

startIp=sys.argv[1]
deviceCount=sys.argv[2]
typeOfDevice=sys.argv[3]

Listof2IPs=[]
count=1

def create_Ip_list():
    global count
    startIpList = startIp.split(".")
    third_index = int(startIpList[2])
    fourth_index = int(startIpList[3])
    for thirdIndex in range(third_index, 256):
        temp = [];
        for fourthIndex in range(fourth_index, 256):
            ip_Address = str(startIpList[0]) + "." + str(startIpList[1]) + "." + str(thirdIndex) + "." + str(
                fourthIndex);
            temp.append(ip_Address)
            if len(temp)==2:
                Listof2IPs.append(temp)
                temp = [];
            print count;
            count = count + 1;
            if count > int(deviceCount):
                break;
        if count > int(deviceCount):
            break;

#create Ip list
create_Ip_list()

if typeOfDevice == 'linux':
    src_dir_apspath = os.path.abspath('./device_flow_data_template/Linux')
if typeOfDevice == 'window':
    src_dir_apspath = os.path.abspath('./device_flow_data_template/Window')
dst_dir_apspath = os.path.abspath('./FLOWS_MONITORING')

for listTemp in Listof2IPs:
    try:
        for filename in os.listdir(src_dir_apspath):
            src = src_dir_apspath +'/'+ filename
            if "1device1" in filename:
                dst = dst_dir_apspath + '/' + filename.replace("1device1",listTemp[0])
            else:
                dst = dst_dir_apspath + '/' + filename.replace("2device2", listTemp[1])
            with open(src, 'rb') as src, open(dst, 'wb') as dst:
                    content = src.read()
                    content = content.replace("1device1",listTemp[0])
                    content = content.replace("2device2",listTemp[1])
                    dst.write(content)
    except Exception as e:
        print e


