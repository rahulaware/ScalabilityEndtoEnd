import os
import sys
import random

def randomMAC():
    return [
        random.randint(0x00, 0x7f),
        random.randint(0x00, 0xff),
        random.randint(0x00, 0x7f),
        random.randint(0x00, 0x7f),
        random.randint(0x00, 0xff),
        random.randint(0x00, 0xff) ]

def randomMAC_Switch():
    return [
        random.randint(0x00, 0x7f),
        random.randint(0x00, 0xff),
        random.randint(0x00, 0x7f)]

def MACprettyprint_switch(mac):
    return '.'.join(map(lambda x: "%04x" % x, mac))

def MACprettyprint_linux(mac):
    return ':'.join(map(lambda x: "%02x" % x, mac))

def MACprettyprint_window(mac):
    return '-'.join(map(lambda x: "%02x" % x, mac))


if len(sys.argv)<4:
    print "Command Usage:"
    print "python create_dummy_devices.py hostname NumberOfDevices typeOfDevice(window,linux,hypervisor,network) startIP"
    print "Prefered start IP: linux[10.50.1.1-10.50.15.255],window[10.50.16.1-10.50.30.255],network[10.50.31.1-10.50.40.255],hypervisor[10.50.41.1-10.50.45.255]"
    exit();

hostName=sys.argv[1]
deviceCount=sys.argv[2]
typeOfDevice=sys.argv[3]
startIp=sys.argv[4]
startIpList= startIp.split(".")


third_index=int(startIpList[2])
fourth_index=int(startIpList[3])

template_old_ip="";
template_old_hostname="";


if typeOfDevice == 'linux':
    template_old_ip = "182.1.91.15";
    template_old_hostname = "appserver91-15";
    template_old_mac_address="00:50:56:A7:F2:D8"

if typeOfDevice == 'window':
    template_old_ip = "172.16.2.136";
    template_old_hostname = "win-2012-r2-cn1"
    template_old_mac_address= "00-15-5D-02-1C-05"

if typeOfDevice == 'network':
    template_old_ip = "172.16.1.23";
    template_old_hostname = "fs-5672-2";
    template_old_mac_address= "002a.6af9.4401"

if typeOfDevice == 'hypervisor':
    template_old_ip = "172.16.2.88";
    template_old_hostname = "esxi-8";


print type(deviceCount)
count=1;
for thirdIndex in range(third_index,255):
    for fourthIndex in range(fourth_index,255):
        ip_Address=str(startIpList[0])+"."+str(startIpList[1])+"."+str(thirdIndex)+"."+str(fourthIndex);
        #create device discovery data
        src_dir_apspath = os.path.abspath('./device_discovery_data_template/'+typeOfDevice)
        dst_dir_apspath = os.path.abspath('./DEVICE_DISCOVERY')
        #print "src apspath :",src_dir_apspath
        #print "dst apspath :",dst_dir_apspath
        for filename in os.listdir(src_dir_apspath):
            #print filename
            src = src_dir_apspath +'/'+ filename
            dst = dst_dir_apspath +'/'+ filename.replace(template_old_ip,ip_Address)
            #print "src path :",src
            #print "dst path :",dst
	    with open(src, 'rb') as src, open(dst, 'wb') as dst:
                content = src.read()
                content = content.replace(template_old_ip,ip_Address)
                content = content.replace(template_old_hostname,hostName+str(count))
                content = content.replace(template_old_hostname.upper(),hostName+str(count))

                if typeOfDevice == 'linux':
                    newHardwareAddess = MACprettyprint_linux(randomMAC())
                    content = content.replace(template_old_mac_address, newHardwareAddess)
                if typeOfDevice == 'window':
                    newHardwareAddess = MACprettyprint_window(randomMAC())
                    content = content.replace(template_old_mac_address, newHardwareAddess)
                if typeOfDevice == 'network':
                    newHardwareAddess = MACprettyprint_switch(randomMAC_Switch())
                    content = content.replace(template_old_mac_address, newHardwareAddess)

                # if typeOfDevice == 'hypervisor':
                #print content
                dst.write(content)
        #create device performance data
        src_dir_apspath = os.path.abspath('./device_performance_data_template/'+typeOfDevice)
        dst_dir_apspath = os.path.abspath('./DEVICE_MONITORING')
        for filename in os.listdir(src_dir_apspath):
            #print filename
            src = src_dir_apspath + '/' + filename
            dst = dst_dir_apspath + '/' + filename.replace(template_old_ip, ip_Address)
            with open(src, 'rb') as src, open(dst, 'wb') as dst:
                content = src.read()
                content = content.replace(template_old_ip, ip_Address)
                content = content.replace(template_old_hostname, hostName + str(count))
                content = content.replace(template_old_hostname.upper(), hostName + str(count))
                dst.write(content)
            #shutil.copy(src_dir_apspath+'/'+src_file_name,dst_dir_apspath+'/'+dst_file_name)
        #if device count exceed then break loop
        print count;
        count=count +1;
        if count > int(deviceCount):
            break;
    if count > int(deviceCount):
        break;    

